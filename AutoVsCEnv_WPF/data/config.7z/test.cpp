// 这是一个调试测试文件，您可以直接运行检测配置是否生效
// 若配置任然无法调试，请查阅README_inProject.md

#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("Congratulasions! It works!\n");
    system("pause");
    return 0;
}